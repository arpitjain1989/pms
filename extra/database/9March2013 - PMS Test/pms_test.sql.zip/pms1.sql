-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 09, 2013 at 07:36 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pms1`
--

-- --------------------------------------------------------

--
-- Table structure for table `pms_admin`
--

CREATE TABLE IF NOT EXISTS `pms_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `pms_admin`
--

INSERT INTO `pms_admin` (`id`, `name`, `email`, `phone`, `username`, `password`, `created_date`) VALUES
(1, 'Admin', 'test@transformsolution.net', 1234567890, 'admin', '2eef28ab3d5273ba75abc953cbadb80b', '2013-01-22 05:56:42');

-- --------------------------------------------------------

--
-- Table structure for table `pms_attendance`
--

CREATE TABLE IF NOT EXISTS `pms_attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `in_time` time NOT NULL,
  `out_time` time NOT NULL,
  `break1_in` time NOT NULL,
  `break1_out` time NOT NULL,
  `break2_in` time NOT NULL,
  `break2_out` time NOT NULL,
  `break3_in` time NOT NULL,
  `break3_out` time NOT NULL,
  `leave_id` int(11) NOT NULL,
  `is_late` tinyint(1) NOT NULL,
  `total_break_time` time NOT NULL,
  `isExceededBreak` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=74 ;

--
-- Dumping data for table `pms_attendance`
--

INSERT INTO `pms_attendance` (`id`, `user_id`, `date`, `in_time`, `out_time`, `break1_in`, `break1_out`, `break2_in`, `break2_out`, `break3_in`, `break3_out`, `leave_id`, `is_late`, `total_break_time`, `isExceededBreak`) VALUES
(1, 8, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(2, 9, '2013-03-13 00:00:00', '06:45:00', '03:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(3, 9, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(4, 10, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(5, 11, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(6, 11, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(7, 12, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(8, 12, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(9, 13, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(10, 13, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(11, 14, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(12, 14, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(13, 15, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(14, 15, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(15, 16, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(16, 16, '2013-03-14 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 1, 0, '00:00:00', 0),
(17, 16, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(18, 17, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(19, 17, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(20, 18, '2013-03-12 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 14, 0, '00:00:00', 0),
(21, 18, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(22, 18, '2013-03-14 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 1, 0, '00:00:00', 0),
(23, 18, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(24, 19, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(25, 19, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(26, 20, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(27, 20, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(28, 21, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(29, 21, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(30, 22, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(31, 22, '2013-03-14 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 13, 0, '00:00:00', 0),
(32, 22, '2013-03-16 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 13, 0, '00:00:00', 0),
(33, 22, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(34, 23, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(35, 23, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(36, 24, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(37, 24, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(38, 25, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(39, 25, '2013-03-15 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(40, 25, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(41, 26, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(42, 26, '2013-03-14 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(43, 26, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(44, 27, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(45, 27, '2013-03-16 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(46, 27, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(47, 23, '2013-03-14 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 13, 0, '00:00:00', 0),
(48, 26, '2013-03-16 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(49, 5, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(50, 6, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(51, 7, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(52, 28, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(53, 29, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(54, 30, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(55, 31, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(56, 32, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(57, 33, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(58, 34, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(59, 35, '2013-03-17 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0),
(60, 5, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(61, 6, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(62, 7, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(63, 8, '2013-03-13 00:00:00', '07:00:00', '15:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 0, 0, '00:00:00', 0),
(64, 10, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(65, 28, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(66, 29, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(67, 30, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(68, 31, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(69, 32, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(70, 33, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(71, 34, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(72, 35, '2013-03-13 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 10, 0, '00:00:00', 0),
(73, 10, '2013-03-14 00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 9, 0, '00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pms_attendance_report`
--

CREATE TABLE IF NOT EXISTS `pms_attendance_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `present` float(5,2) NOT NULL,
  `break_exceeds` float(5,2) NOT NULL,
  `total_plt` float(5,2) NOT NULL,
  `ppl` float(5,2) NOT NULL,
  `uhl` float(5,2) NOT NULL,
  `wo` int(11) NOT NULL,
  `ph` int(11) NOT NULL,
  `ha` float(5,2) NOT NULL,
  `hlwp` float(5,2) NOT NULL,
  `abs` float(5,2) NOT NULL,
  `plwp` float(5,2) NOT NULL,
  `ulwp` float(5,2) NOT NULL,
  `nj` float(5,2) NOT NULL,
  `le` float(5,2) NOT NULL,
  `awol` float(5,2) NOT NULL,
  `total_present` float(5,2) NOT NULL,
  `pay_days` float(5,2) NOT NULL,
  `opening_leave` float(5,2) NOT NULL,
  `leave_earns` float(5,2) NOT NULL,
  `pl_taken` float(5,2) NOT NULL,
  `eml_taken` float(5,2) NOT NULL,
  `phl_taken` float(5,2) NOT NULL,
  `uhl_taken` float(5,2) NOT NULL,
  `total_leave_taken` float(5,2) NOT NULL,
  `closing_balance` float(5,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pms_clients`
--

CREATE TABLE IF NOT EXISTS `pms_clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `display_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pms_departments`
--

CREATE TABLE IF NOT EXISTS `pms_departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `pms_departments`
--

INSERT INTO `pms_departments` (`id`, `title`, `description`) VALUES
(1, 'Non-voice', '');

-- --------------------------------------------------------

--
-- Table structure for table `pms_designation`
--

CREATE TABLE IF NOT EXISTS `pms_designation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `pms_designation`
--

INSERT INTO `pms_designation` (`id`, `title`, `description`) VALUES
(5, 'BPOExecutive', ''),
(6, 'AsstManager-Operation', ''),
(7, 'Team Leader', ''),
(8, 'Admin', ''),
(9, 'BPO-Trainee', ''),
(10, 'Sr.BPOExecutive', '');

-- --------------------------------------------------------

--
-- Table structure for table `pms_employee`
--

CREATE TABLE IF NOT EXISTS `pms_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `teamleader` int(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `role` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `leave_bal` int(11) NOT NULL,
  `shiftid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `pms_employee`
--

INSERT INTO `pms_employee` (`id`, `employee_code`, `name`, `email`, `contact`, `address`, `department`, `designation`, `teamleader`, `password`, `status`, `role`, `username`, `leave_bal`, `shiftid`) VALUES
(1, 'Emp-1', 'Asfaq Shiliwala', 'asfaq@transformsolution.com', 'zxczxc', 'sdfsdf', '1', '8', 0, 'e10adc3949ba59abbe56e057f20f883e', '0', 20, 'asfaq', 0, 9),
(2, 'Emp-2', 'Mukesh Tiwari', 'mukesh.tiwari@transformsolution.net', '', '', '1', '6', 1, 'e10adc3949ba59abbe56e057f20f883e', '0', 19, 'mukesh.tiwari', 0, 9),
(3, 'Emp-3', 'Vikas Sharma', 'vikas.sharma@transformsolution.net', '', '', '1', '6', 1, 'e10adc3949ba59abbe56e057f20f883e', '0', 19, 'vikas.sharma', 0, 9),
(4, 'Emp-4', 'Gaurang Patel', 'gaurang@transformsolution.net', '', '', '1', '6', 1, 'e10adc3949ba59abbe56e057f20f883e', '0', 19, 'gaurang', 0, 9),
(5, 'Emp-5', 'Nilesh Kota', 'nileshkota@transformsolution.net', '', '', '1', '7', 2, 'e10adc3949ba59abbe56e057f20f883e', '0', 18, 'nileshkota', 0, 6),
(6, 'Emp-6', 'Divakar Chaturvedi', 'divakar.chaturvedi@transformsolution.net', '', '', '1', '7', 3, 'e10adc3949ba59abbe56e057f20f883e', '0', 18, 'divakar.chaturvedi', 0, 6),
(7, 'Emp-7', 'Mazharahmed Retiwala', 'mazhar.ahmed@transformsolution.net', '', '', '1', '7', 4, 'e10adc3949ba59abbe56e057f20f883e', '0', 18, 'mazhar.ahmed', 0, 7),
(8, 'Emp-8', 'Abhilasha Dheniya', 'abhilasha.dheniya@transformsolution.net', '', '', '1', '5', 5, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'abhilasha.dheniya', 0, 6),
(9, 'Emp-9', 'Akram Patel', 'akram.patel@transformsolution.net', '', '', '1', '5', 5, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'akram.patel', 0, 6),
(10, 'Emp-10', 'Aakash Bhavsar', 'akash.bhavsar@transformsolution.net', '', '', '1', '5', 5, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'akash.bhavsar', 0, 6),
(11, 'Emp-11', 'Ali Saiyed', 'ali.saiyed@transformsolution.net', '', '', '1', '5', 5, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'ali.saiyed', 0, 6),
(12, 'Emp-12', 'Arpita Maity', 'arpita.maity@transformsolution.net', '', '', '1', '5', 5, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'arpita.maity', 0, 6),
(13, 'Emp-13', 'Bindusagar Senapati', 'bindusagar.senapati@transformsolution.net', '', '', '1', '5', 5, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'bindusagar.senapati', 0, 6),
(14, 'Emp-14', 'Imran Patel', 'imran.patel@transformsolution.net', '', '', '1', '5', 5, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'imran.patel', 0, 6),
(15, 'Emp-15', 'Imtiaz Ansari', 'imtiyaz.ansari@transformsolution.net', '', '', '1', '5', 5, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'imtiyaz.ansari', 0, 6),
(16, 'Emp-16', 'Jyoti Malhotra', 'jyoti.malhotra@transformsolution.net', '', '', '1', '5', 5, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'jyoti.malhotra', 0, 6),
(17, 'Emp-17', 'Khyati Patel', 'khyati.patel@transformsolution.net', '', '', '1', '5', 5, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'khyati.patel', 0, 6),
(18, 'Emp-18', 'Mital Nayi', 'mital.nayi@transformsolution.net', '', '', '1', '5', 5, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'mital.nayi', 0, 6),
(19, 'Emp-19', 'Shailesh Singh', 'shailesh.singh@transformsolution.net', '', '', '1', '5', 5, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'shailesh.singh', 0, 6),
(20, 'Emp-20', 'Shobhan Mistry', 'shobhan.mistry@transformsolution.net', '', '', '1', '5', 5, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'shobhan.mistry', 0, 6),
(21, 'Emp-21', 'Suraj Khedekar', 'suraj.khedekar@transformsolution.net', '', '', '1', '5', 5, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'suraj.khedekar', 0, 6),
(22, 'Emp-22', 'Hamid Chandiwala', 'hamid.chandiwala@transformsolution.net', '', '', '1', '5', 6, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'hamid.chandiwala', 0, 8),
(23, 'Emp-23', 'Chirag Majethia', 'chirag.majethia@transformsolution.net', '', '', '1', '9', 6, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'chirag.majethia', 0, 9),
(24, 'Emp-24', 'Jasdeep Bedi', 'jasdeep.bedi@transformsolution.net', '', '', '1', '5', 6, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'jasdeep.bedi', 0, 6),
(25, 'Emp-25', 'Niral Ramani', 'niral.ramani@transformsolution.net', '', '', '1', '10', 6, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'niral.ramani', 0, 6),
(26, 'Emp-26', 'Prateek Gairola', 'prateek.gairola@transformsolution.net', '', '', '1', '10', 6, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'prateek.gairola', 0, 6),
(27, 'Emp-27', 'Amiteshkumar Rajput', 'amiteshkumar.rajput@transformsolution.net', '', '', '1', '9', 6, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'amiteshkumar.rajput', 0, 10),
(28, 'Emp-28', 'Mohd Aslam Shaikh', 'mohdaslam.shaikh@transformsolution.net', '', '', '1', '5', 7, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'mohdaslam.shaikh', 0, 7),
(29, 'Emp-29', 'Juned Multani', 'juned.multani@transformsolution.net', '', '', '1', '5', 7, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'juned.multani', 0, 7),
(30, 'Emp-30', 'Pratik Rashmikant Patel', 'pratikrashmikant.patel@transformsolution.net', '', '', '1', '5', 7, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'pratikrashmikant.patel', 0, 7),
(31, 'Emp-31', 'Nisarg Patel', 'nisarg.patel@transformsolution.net', '', '', '1', '5', 7, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'nisarg.patel', 0, 7),
(32, 'Emp-32', 'Krunal Dhimmar', 'krunal.dhimmar@transformsolution.net', '', '', '1', '5', 7, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'krunal.dhimmar', 0, 7),
(33, 'Emp-33', 'Manoj Mangukiya', 'manoj.mangukiya@transformsolution.net', '', '', '1', '9', 7, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'manoj.mangukiya', 0, 7),
(34, 'Emp-34', 'Boni Paronigar', 'boni.paronigar@transformsolution.net', '', '', '1', '9', 7, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'boni.paronigar', 0, 7),
(35, 'Emp-35', 'Miraz Sarkar', 'miraz.sarkar@transformsolution.net', '', '', '1', '5', 7, 'e10adc3949ba59abbe56e057f20f883e', '0', 17, 'miraz.sarkar', 0, 7);

-- --------------------------------------------------------

--
-- Table structure for table `pms_form`
--

CREATE TABLE IF NOT EXISTS `pms_form` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pms_form_field`
--

CREATE TABLE IF NOT EXISTS `pms_form_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `iscompulsory` tinyint(1) NOT NULL,
  `validation_rule` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pms_holidays`
--

CREATE TABLE IF NOT EXISTS `pms_holidays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `holidaydate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `pms_holidays`
--

INSERT INTO `pms_holidays` (`id`, `title`, `holidaydate`) VALUES
(1, 'Uttarayan / Makar Sankranti', '2013-01-14 00:00:00'),
(2, 'Republic Day', '2013-01-26 00:00:00'),
(3, 'Dhuleti (Holi)', '2013-03-27 00:00:00'),
(4, 'Ramadaan Eid/ Eid-ul-fitr', '2013-08-09 00:00:00'),
(5, 'Independence Day', '2013-08-15 00:00:00'),
(6, 'Ganesh Visarjan', '2013-09-18 00:00:00'),
(7, 'Gandhi Jayanti', '2013-10-02 00:00:00'),
(8, 'Diwali', '2013-11-03 00:00:00'),
(9, 'Gujarati New Year', '2013-11-04 00:00:00'),
(10, 'Testing', '2013-03-13 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `pms_job_types`
--

CREATE TABLE IF NOT EXISTS `pms_job_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `root_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pms_leave_form`
--

CREATE TABLE IF NOT EXISTS `pms_leave_form` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nodays` int(11) NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `reason` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `date` datetime NOT NULL,
  `employee_id` int(11) NOT NULL,
  `status` tinyint(2) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `status_manager` tinyint(2) NOT NULL,
  `approved_date` datetime NOT NULL,
  `comment_manager` varchar(255) NOT NULL,
  `approved_date_manager` datetime NOT NULL,
  `teamleader_id` int(11) NOT NULL,
  `manager_id` int(11) NOT NULL,
  `ph` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `pms_leave_form`
--

INSERT INTO `pms_leave_form` (`id`, `nodays`, `start_date`, `end_date`, `reason`, `address`, `contact`, `date`, `employee_id`, `status`, `comment`, `status_manager`, `approved_date`, `comment_manager`, `approved_date_manager`, `teamleader_id`, `manager_id`, `ph`) VALUES
(1, 3, '2013-03-06 00:00:00', '2013-03-08 00:00:00', 'test', 'test', '12324345', '2013-03-05 00:00:00', 8, 1, 'zxcZXC', 1, '2013-03-05 00:00:00', 'dsfsadfadsf asdfsd', '2013-03-05 00:00:00', 5, 2, 0),
(2, 2, '2013-03-07 00:00:00', '2013-03-08 00:00:00', 'jkfdhlsda lsadjf hsldafh ', 'jkfdhlsda lsadjf hsldafh j', '123456789', '2013-03-05 00:00:00', 12, 1, 'zxcZXC', 0, '2013-03-06 00:00:00', '', '2013-03-06 00:00:00', 5, 2, 0),
(3, 2, '2013-03-20 00:00:00', '2013-03-21 00:00:00', 'sdkfl sdkfh', 'sdkjfs hdafhdsf', '123456', '2013-03-05 00:00:00', 23, 1, 'v sdfg sdfgsd fg', 1, '2013-03-08 00:00:00', 'gfhh fg fg gh', '2013-03-08 00:00:00', 6, 3, 0),
(4, 2, '2013-03-08 00:00:00', '2013-03-09 00:00:00', 'lkjshjk sahasdh ajsh', 'sdkljafh jsdhf lsajkdfh', '213546548', '2013-03-05 00:00:00', 5, 0, '', 0, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 2, 0, 0),
(5, 2, '2013-03-13 00:00:00', '2013-03-14 00:00:00', 'sdafasdf asd asdf', 'sdaf asdf asdf', '45213452345', '2013-03-06 00:00:00', 18, 1, 'as asd asd asd', 0, '2013-03-06 00:00:00', '', '2013-03-06 00:00:00', 5, 2, 0),
(6, 1, '2013-03-14 00:00:00', '2013-03-14 00:00:00', 'sadjkfhkljasd hlasdhf', 'sadjkfhkljasd hlasdhf', '12378123', '2013-03-06 00:00:00', 16, 0, '', 1, '2013-03-06 00:00:00', 'fghdg dh fgh', '2013-03-06 00:00:00', 5, 2, 0),
(7, 2, '2013-03-15 00:00:00', '2013-03-16 00:00:00', 'asjkd fsd hfasdf', 'sdfj slakdj', '12324345', '2013-03-06 00:00:00', 22, 2, 'v sdfg sdfgsd fg', 0, '2013-03-06 00:00:00', '', '2013-03-06 00:00:00', 6, 3, 0),
(9, 2, '2013-03-27 00:00:00', '2013-03-28 00:00:00', 'aaaaaaaaa', 'bbbbbb', '1233456789', '2013-03-06 00:00:00', 9, 1, 'approved', 1, '2013-03-06 00:00:00', 'yes its approved', '2013-03-06 00:00:00', 5, 2, 0),
(10, 2, '2013-03-28 00:00:00', '2013-03-29 00:00:00', 'sadfsdfasd', 'sadfsdafsadf', '+91-242342342', '2013-03-06 00:00:00', 5, 0, '', 0, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 2, 0, 0),
(11, 2, '2013-03-29 00:00:00', '2013-03-30 00:00:00', 'sadfdasf', 'sadfsdf', '242424234', '2013-03-06 00:00:00', 6, 0, '', 0, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 3, 0, 0),
(14, 2, '2013-03-11 00:00:00', '2013-03-12 00:00:00', 'sfsf sfs adfsadfsdafsdf', 'sadfasdf sfsdf sadfsf', '44131321313-12', '2013-03-06 00:00:00', 6, 0, '', 0, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 3, 0, 0),
(15, 4, '2013-04-10 00:00:00', '2013-04-13 00:00:00', 'aaaaaaaaa', 'rrrrrrrrrrrr', '222222222', '2013-03-06 00:00:00', 9, 2, 'fasdfsa fsdfd asf', 2, '2013-03-06 00:00:00', 'fasdfsa fsdfd asf', '2013-03-06 00:00:00', 5, 2, 0),
(32, 1, '2013-04-03 00:00:00', '2013-04-03 00:00:00', 'sadf safd ', 'sdaf sadfa fsadf', '+91-242342342', '2013-03-09 00:00:00', 8, 0, '', 0, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 5, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pms_leave_history`
--

CREATE TABLE IF NOT EXISTS `pms_leave_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL,
  `added_no_of_leaves` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `reason` text NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pms_leave_type`
--

CREATE TABLE IF NOT EXISTS `pms_leave_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `pms_leave_type`
--

INSERT INTO `pms_leave_type` (`id`, `title`, `description`, `color`) VALUES
(1, 'PPL', 'Planned Leave', '#ffbad2\n'),
(2, 'UPL', 'Unplanned Leave', '#CD96CD'),
(3, 'A', 'Absent', '#FF6103'),
(4, 'PHL', 'Planned half day leave', '#CD919E'),
(5, 'UHL', 'Unplanned half day leave', '#bda0cb'),
(6, 'PLWP', 'Planned leave without pay', '#EE9A00'),
(7, 'ULWP', 'Unplanned leave without pay', '#EEAD0E'),
(8, 'HLWP', 'Half day leave without pay ', '#EE8833'),
(9, 'WO', 'Weekaly off', '#CBCAB6'),
(10, 'PH', 'Public holiday ', '#EAEAAE'),
(11, 'SM+PLT', 'Shift mooment and late coming both', '#EBCEAC'),
(12, 'HA', 'Half day absent ', '#FFA07A'),
(13, 'SC', 'Shift Change', '#a8f7c2'),
(14, 'SM', 'Shift Movement', '#05e83a');

-- --------------------------------------------------------

--
-- Table structure for table `pms_module`
--

CREATE TABLE IF NOT EXISTS `pms_module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `pms_module`
--

INSERT INTO `pms_module` (`id`, `title`, `description`) VALUES
(1, 'Roles', ''),
(2, 'Departments', ''),
(3, 'Designation', ''),
(4, 'Employee', ''),
(5, 'Project', ''),
(6, 'Billing Method', ''),
(7, 'Task', ''),
(8, 'Clients', ''),
(9, 'Form Fields', ''),
(10, 'Site Settings', ''),
(11, 'Leave Type', ''),
(12, 'Leave Form', ''),
(13, 'Shift', ''),
(14, 'Attendance', ''),
(15, 'Leave Request', ''),
(16, 'Attendance Calendar', ''),
(17, 'Shift Movement', ''),
(18, 'Shift Movement Request', ''),
(19, 'Roster', ''),
(20, 'Shift Movement Cancellation', ''),
(21, 'Emergency Shift Movement', ''),
(22, 'Shift Movement Compensation', ''),
(23, 'Shift Movement Compensation Request', ''),
(24, 'Holidays', '');

-- --------------------------------------------------------

--
-- Table structure for table `pms_project`
--

CREATE TABLE IF NOT EXISTS `pms_project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `client` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `form` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pms_project_fields`
--

CREATE TABLE IF NOT EXISTS `pms_project_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_name` int(11) DEFAULT NULL,
  `formid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pms_roles`
--

CREATE TABLE IF NOT EXISTS `pms_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `pms_roles`
--

INSERT INTO `pms_roles` (`id`, `title`, `description`) VALUES
(17, 'Agent', 'This have only agent rights....'),
(18, 'Team Leader', ''),
(19, 'Manager', ''),
(20, 'CEO', '');

-- --------------------------------------------------------

--
-- Table structure for table `pms_role_details`
--

CREATE TABLE IF NOT EXISTS `pms_role_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `modules` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=311 ;

--
-- Dumping data for table `pms_role_details`
--

INSERT INTO `pms_role_details` (`id`, `role_id`, `modules`) VALUES
(53, 2, 1),
(54, 2, 2),
(55, 2, 3),
(56, 2, 4),
(57, 8, 1),
(58, 8, 2),
(59, 8, 3),
(60, 9, 2),
(61, 9, 3),
(62, 9, 4),
(65, 12, 1),
(66, 12, 2),
(67, 12, 3),
(68, 12, 4),
(69, 13, 5),
(70, 13, 6),
(71, 13, 7),
(72, 15, 1),
(73, 15, 2),
(74, 15, 4),
(75, 15, 5),
(76, 16, 1),
(77, 16, 2),
(78, 16, 8),
(286, 17, 12),
(287, 17, 16),
(288, 17, 17),
(289, 17, 22),
(290, 18, 12),
(291, 18, 15),
(292, 18, 16),
(293, 18, 17),
(294, 18, 18),
(295, 18, 19),
(296, 18, 21),
(297, 18, 22),
(298, 18, 23),
(299, 19, 12),
(300, 19, 15),
(301, 19, 16),
(302, 19, 17),
(303, 19, 18),
(304, 19, 19),
(305, 19, 21),
(306, 19, 23),
(309, 20, 16),
(310, 20, 18);

-- --------------------------------------------------------

--
-- Table structure for table `pms_roster`
--

CREATE TABLE IF NOT EXISTS `pms_roster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `weekoffdate` datetime DEFAULT NULL,
  `weekoffday` varchar(255) DEFAULT NULL,
  `addedon` datetime DEFAULT NULL,
  `addedby` int(11) DEFAULT NULL,
  `autoadded` tinyint(1) DEFAULT NULL,
  `reportinghead` int(11) DEFAULT NULL,
  `secondreportinghead` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `pms_roster`
--

INSERT INTO `pms_roster` (`id`, `userid`, `start_date`, `end_date`, `weekoffdate`, `weekoffday`, `addedon`, `addedby`, `autoadded`, `reportinghead`, `secondreportinghead`) VALUES
(1, 8, '2013-03-11 00:00:00', '2013-03-17 00:00:00', '2013-03-17 00:00:00', 'Sunday', '2013-03-09 12:43:26', 5, 0, 5, 2),
(2, 9, '2013-03-11 00:00:00', '2013-03-17 00:00:00', '2013-03-17 00:00:00', 'Sunday', '2013-03-09 12:43:26', 5, 0, 5, 2),
(3, 10, '2013-03-11 00:00:00', '2013-03-17 00:00:00', '2013-03-14 00:00:00', 'Thursday', '2013-03-09 12:43:26', 5, 0, 5, 2),
(4, 11, '2013-03-11 00:00:00', '2013-03-17 00:00:00', '2013-03-17 00:00:00', 'Sunday', '2013-03-09 12:43:26', 5, 0, 5, 2),
(5, 12, '2013-03-11 00:00:00', '2013-03-17 00:00:00', '2013-03-17 00:00:00', 'Sunday', '2013-03-09 12:43:26', 5, 0, 5, 2),
(6, 13, '2013-03-11 00:00:00', '2013-03-17 00:00:00', '2013-03-17 00:00:00', 'Sunday', '2013-03-09 12:43:26', 5, 0, 5, 2),
(7, 14, '2013-03-11 00:00:00', '2013-03-17 00:00:00', '2013-03-17 00:00:00', 'Sunday', '2013-03-09 12:43:26', 5, 0, 5, 2),
(8, 15, '2013-03-11 00:00:00', '2013-03-17 00:00:00', '2013-03-17 00:00:00', 'Sunday', '2013-03-09 12:43:26', 5, 0, 5, 2),
(9, 16, '2013-03-11 00:00:00', '2013-03-17 00:00:00', '2013-03-17 00:00:00', 'Sunday', '2013-03-09 12:43:26', 5, 0, 5, 2),
(10, 17, '2013-03-11 00:00:00', '2013-03-17 00:00:00', '2013-03-17 00:00:00', 'Sunday', '2013-03-09 12:43:26', 5, 0, 5, 2),
(11, 18, '2013-03-11 00:00:00', '2013-03-17 00:00:00', '2013-03-17 00:00:00', 'Sunday', '2013-03-09 12:43:26', 5, 0, 5, 2),
(12, 19, '2013-03-11 00:00:00', '2013-03-17 00:00:00', '2013-03-17 00:00:00', 'Sunday', '2013-03-09 12:43:26', 5, 0, 5, 2),
(13, 20, '2013-03-11 00:00:00', '2013-03-17 00:00:00', '2013-03-17 00:00:00', 'Sunday', '2013-03-09 12:43:26', 5, 0, 5, 2),
(14, 21, '2013-03-11 00:00:00', '2013-03-17 00:00:00', '2013-03-17 00:00:00', 'Sunday', '2013-03-09 12:43:26', 5, 0, 5, 2);

-- --------------------------------------------------------

--
-- Table structure for table `pms_roster_detail`
--

CREATE TABLE IF NOT EXISTS `pms_roster_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rosterid` int(11) DEFAULT NULL,
  `rostereddate` datetime DEFAULT NULL,
  `attendance` varchar(10) DEFAULT NULL,
  `shiftid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=99 ;

--
-- Dumping data for table `pms_roster_detail`
--

INSERT INTO `pms_roster_detail` (`id`, `rosterid`, `rostereddate`, `attendance`, `shiftid`) VALUES
(1, 1, '2013-03-11 00:00:00', 'P', 6),
(2, 1, '2013-03-12 00:00:00', 'P', 6),
(3, 1, '2013-03-13 00:00:00', 'PH', 6),
(4, 1, '2013-03-14 00:00:00', 'P', 6),
(5, 1, '2013-03-15 00:00:00', 'P', 6),
(6, 1, '2013-03-16 00:00:00', 'P', 6),
(7, 1, '2013-03-17 00:00:00', 'WO', 6),
(8, 2, '2013-03-11 00:00:00', 'P', 6),
(9, 2, '2013-03-12 00:00:00', 'P', 6),
(10, 2, '2013-03-13 00:00:00', 'PH', 6),
(11, 2, '2013-03-14 00:00:00', 'P', 6),
(12, 2, '2013-03-15 00:00:00', 'P', 6),
(13, 2, '2013-03-16 00:00:00', 'P', 6),
(14, 2, '2013-03-17 00:00:00', 'WO', 6),
(15, 3, '2013-03-11 00:00:00', 'P', 6),
(16, 3, '2013-03-12 00:00:00', 'P', 6),
(17, 3, '2013-03-13 00:00:00', 'P', 6),
(18, 3, '2013-03-14 00:00:00', 'WO', 6),
(19, 3, '2013-03-15 00:00:00', 'P', 6),
(20, 3, '2013-03-16 00:00:00', 'P', 6),
(21, 3, '2013-03-17 00:00:00', 'P', 6),
(22, 4, '2013-03-11 00:00:00', 'P', 6),
(23, 4, '2013-03-12 00:00:00', 'P', 6),
(24, 4, '2013-03-13 00:00:00', 'PH', 6),
(25, 4, '2013-03-14 00:00:00', 'P', 6),
(26, 4, '2013-03-15 00:00:00', 'P', 6),
(27, 4, '2013-03-16 00:00:00', 'P', 6),
(28, 4, '2013-03-17 00:00:00', 'WO', 6),
(29, 5, '2013-03-11 00:00:00', 'P', 6),
(30, 5, '2013-03-12 00:00:00', 'P', 6),
(31, 5, '2013-03-13 00:00:00', 'PH', 6),
(32, 5, '2013-03-14 00:00:00', 'P', 6),
(33, 5, '2013-03-15 00:00:00', 'P', 6),
(34, 5, '2013-03-16 00:00:00', 'P', 6),
(35, 5, '2013-03-17 00:00:00', 'WO', 6),
(36, 6, '2013-03-11 00:00:00', 'P', 6),
(37, 6, '2013-03-12 00:00:00', 'P', 6),
(38, 6, '2013-03-13 00:00:00', 'PH', 6),
(39, 6, '2013-03-14 00:00:00', 'P', 6),
(40, 6, '2013-03-15 00:00:00', 'P', 6),
(41, 6, '2013-03-16 00:00:00', 'P', 6),
(42, 6, '2013-03-17 00:00:00', 'WO', 6),
(43, 7, '2013-03-11 00:00:00', 'P', 6),
(44, 7, '2013-03-12 00:00:00', 'P', 6),
(45, 7, '2013-03-13 00:00:00', 'PH', 6),
(46, 7, '2013-03-14 00:00:00', 'P', 6),
(47, 7, '2013-03-15 00:00:00', 'P', 6),
(48, 7, '2013-03-16 00:00:00', 'P', 6),
(49, 7, '2013-03-17 00:00:00', 'WO', 6),
(50, 8, '2013-03-11 00:00:00', 'P', 6),
(51, 8, '2013-03-12 00:00:00', 'P', 6),
(52, 8, '2013-03-13 00:00:00', 'PH', 6),
(53, 8, '2013-03-14 00:00:00', 'P', 6),
(54, 8, '2013-03-15 00:00:00', 'P', 6),
(55, 8, '2013-03-16 00:00:00', 'P', 6),
(56, 8, '2013-03-17 00:00:00', 'WO', 6),
(57, 9, '2013-03-11 00:00:00', 'P', 6),
(58, 9, '2013-03-12 00:00:00', 'P', 6),
(59, 9, '2013-03-13 00:00:00', 'PH', 6),
(60, 9, '2013-03-14 00:00:00', 'PPL', 6),
(61, 9, '2013-03-15 00:00:00', 'P', 6),
(62, 9, '2013-03-16 00:00:00', 'P', 6),
(63, 9, '2013-03-17 00:00:00', 'WO', 6),
(64, 10, '2013-03-11 00:00:00', 'P', 6),
(65, 10, '2013-03-12 00:00:00', 'P', 6),
(66, 10, '2013-03-13 00:00:00', 'PH', 6),
(67, 10, '2013-03-14 00:00:00', 'P', 6),
(68, 10, '2013-03-15 00:00:00', 'P', 6),
(69, 10, '2013-03-16 00:00:00', 'P', 6),
(70, 10, '2013-03-17 00:00:00', 'WO', 6),
(71, 11, '2013-03-11 00:00:00', 'P', 6),
(72, 11, '2013-03-12 00:00:00', 'SM', 6),
(73, 11, '2013-03-13 00:00:00', 'PH', 6),
(74, 11, '2013-03-14 00:00:00', 'PPL', 6),
(75, 11, '2013-03-15 00:00:00', 'P', 6),
(76, 11, '2013-03-16 00:00:00', 'P', 6),
(77, 11, '2013-03-17 00:00:00', 'WO', 6),
(78, 12, '2013-03-11 00:00:00', 'P', 6),
(79, 12, '2013-03-12 00:00:00', 'P', 6),
(80, 12, '2013-03-13 00:00:00', 'PH', 6),
(81, 12, '2013-03-14 00:00:00', 'P', 6),
(82, 12, '2013-03-15 00:00:00', 'P', 6),
(83, 12, '2013-03-16 00:00:00', 'P', 6),
(84, 12, '2013-03-17 00:00:00', 'WO', 6),
(85, 13, '2013-03-11 00:00:00', 'P', 6),
(86, 13, '2013-03-12 00:00:00', 'P', 6),
(87, 13, '2013-03-13 00:00:00', 'PH', 6),
(88, 13, '2013-03-14 00:00:00', 'P', 6),
(89, 13, '2013-03-15 00:00:00', 'P', 6),
(90, 13, '2013-03-16 00:00:00', 'P', 6),
(91, 13, '2013-03-17 00:00:00', 'WO', 6),
(92, 14, '2013-03-11 00:00:00', 'P', 6),
(93, 14, '2013-03-12 00:00:00', 'P', 6),
(94, 14, '2013-03-13 00:00:00', 'PH', 6),
(95, 14, '2013-03-14 00:00:00', 'P', 6),
(96, 14, '2013-03-15 00:00:00', 'P', 6),
(97, 14, '2013-03-16 00:00:00', 'P', 6),
(98, 14, '2013-03-17 00:00:00', 'WO', 6);

-- --------------------------------------------------------

--
-- Table structure for table `pms_settings`
--

CREATE TABLE IF NOT EXISTS `pms_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` int(12) NOT NULL,
  `email` varchar(255) NOT NULL,
  `website_title` varchar(255) NOT NULL,
  `website_description` varchar(255) NOT NULL,
  `website_keywords` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `pms_settings`
--

INSERT INTO `pms_settings` (`id`, `phone`, `email`, `website_title`, `website_description`, `website_keywords`) VALUES
(1, 1234567890, 'test1@transformsolution.net', 'Transform Solution', 'Transform solution project management System', 'transform,admin,transformsolution');

-- --------------------------------------------------------

--
-- Table structure for table `pms_shift_movement`
--

CREATE TABLE IF NOT EXISTS `pms_shift_movement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `movement_date` datetime DEFAULT NULL,
  `movement_fromtime` time DEFAULT NULL,
  `movement_totime` time DEFAULT NULL,
  `compensation_date` datetime DEFAULT NULL,
  `compensation_fromtime` time DEFAULT NULL,
  `compensation_totime` time DEFAULT NULL,
  `reason` text,
  `addedon` datetime DEFAULT NULL,
  `approvedby_tl` tinyint(1) DEFAULT NULL,
  `lt_comments` text,
  `approvedby_manager` tinyint(1) DEFAULT NULL,
  `manager_comments` text,
  `lt_approval_date` datetime DEFAULT NULL,
  `manager_approval_date` datetime DEFAULT NULL,
  `isCancel` tinyint(1) NOT NULL DEFAULT '0',
  `reportinghead1` int(11) DEFAULT NULL,
  `reportinghead2` int(11) DEFAULT NULL,
  `isemergency` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `pms_shift_movement`
--

INSERT INTO `pms_shift_movement` (`id`, `userid`, `movement_date`, `movement_fromtime`, `movement_totime`, `compensation_date`, `compensation_fromtime`, `compensation_totime`, `reason`, `addedon`, `approvedby_tl`, `lt_comments`, `approvedby_manager`, `manager_comments`, `lt_approval_date`, `manager_approval_date`, `isCancel`, `reportinghead1`, `reportinghead2`, `isemergency`) VALUES
(1, 8, '2013-03-09 00:00:00', '07:00:00', '08:00:00', '2013-03-09 00:00:00', '15:00:00', '16:00:00', 'dfsg sdfg sfdg fdg', '2013-03-05 18:04:29', 0, NULL, 0, NULL, NULL, NULL, 0, 5, 2, 1),
(2, 18, '2013-03-12 00:00:00', '07:00:00', '08:00:00', '2013-03-12 00:00:00', '15:00:00', '16:00:00', 'Testing', '2013-03-06 11:08:57', 1, 'asdasdas as asd asd', 0, NULL, '2013-03-06 11:10:53', NULL, 0, 5, 2, 1),
(3, 6, '2013-03-06 00:00:00', '11:49:00', '12:00:00', '2013-03-06 00:00:00', '19:00:00', '19:30:00', 'sd asdf asdf hsadf sdaf', '2013-03-06 11:45:55', 0, NULL, 0, NULL, NULL, NULL, 0, 3, 1, 1),
(4, 22, '2013-03-07 00:00:00', '10:00:00', '11:15:00', '2013-03-08 00:00:00', '19:00:00', '20:30:00', 'dfs sdfg dfg', '2013-03-06 11:48:59', 1, 'as kajsc hsdkaj fhasdkhflsdkhf', 0, NULL, '2013-03-06 11:49:21', NULL, 0, 6, 3, 1),
(5, 24, '2013-03-15 00:00:00', '15:00:00', '15:45:00', '2013-03-16 00:00:00', '18:00:00', '19:00:00', 'dsfg dfsg sdf sdfg', '2013-03-06 11:52:35', 1, 'jhg kdfs ghdsgh lsdf', 0, NULL, '2013-03-06 11:52:57', NULL, 1, 6, 3, 1),
(6, 24, '2013-03-07 00:00:00', '12:06:00', '13:00:00', '2013-03-07 00:00:00', '19:00:00', '20:00:00', 'fghgdhf dhhh', '2013-03-06 12:03:10', 1, 'ghjfg g g fjfg jf', 0, NULL, '2013-03-06 12:03:33', NULL, 0, 6, 3, 1),
(7, 24, '2013-03-05 00:00:00', '12:06:00', '13:00:00', '2013-03-05 00:00:00', '19:00:00', '20:00:00', 'fghgdhf dhhh', '2013-03-05 12:03:10', 1, 'ghjfg g g fjfg jf', 0, NULL, '2013-03-05 12:03:33', NULL, 0, 6, 3, 1),
(8, 29, '2013-03-05 00:00:00', '12:06:00', '13:00:00', '2013-03-05 00:00:00', '19:00:00', '20:00:00', 'fghgdhf dhhh', '2013-03-05 12:03:10', 1, 'ghjfg g g fjfg jf', 0, NULL, '2013-03-05 12:03:33', NULL, 0, 6, 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pms_shift_movement_compensation`
--

CREATE TABLE IF NOT EXISTS `pms_shift_movement_compensation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `shift_movement_id` int(11) DEFAULT NULL,
  `compensation_date` datetime DEFAULT NULL,
  `compensation_fromtime` time DEFAULT NULL,
  `compensation_totime` time DEFAULT NULL,
  `firstreportingheadid` int(11) DEFAULT NULL,
  `secondreportingheadid` int(11) DEFAULT NULL,
  `approvedby_tl` tinyint(1) DEFAULT NULL,
  `tl_approveddate` datetime DEFAULT NULL,
  `tl_comment` text,
  `addedon` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `pms_shift_movement_compensation`
--

INSERT INTO `pms_shift_movement_compensation` (`id`, `userid`, `shift_movement_id`, `compensation_date`, `compensation_fromtime`, `compensation_totime`, `firstreportingheadid`, `secondreportingheadid`, `approvedby_tl`, `tl_approveddate`, `tl_comment`, `addedon`) VALUES
(1, 24, 7, '2013-03-06 00:00:00', '12:01:00', '13:01:00', 6, 3, 1, '2013-03-06 13:03:36', 'sakj asdj', '2013-03-06 13:01:29'),
(2, 29, 8, '2013-03-06 00:00:00', '14:41:00', '15:41:00', 7, 4, 0, NULL, NULL, '2013-03-06 15:42:30');

-- --------------------------------------------------------

--
-- Table structure for table `pms_shift_times`
--

CREATE TABLE IF NOT EXISTS `pms_shift_times` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `starttime` time NOT NULL,
  `endtime` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `pms_shift_times`
--

INSERT INTO `pms_shift_times` (`id`, `title`, `description`, `starttime`, `endtime`) VALUES
(6, 'Morning', 'Morning Shift', '06:45:00', '14:45:00'),
(7, 'Afternoon', 'Afternoon shift', '15:15:00', '23:15:00'),
(8, 'Morning 6AM', 'Morning shift from 6 AM', '06:00:00', '14:30:00'),
(9, 'Morning 11:30AM', 'Morning shift from 11:30', '11:30:00', '19:30:00'),
(10, 'Morning 9:30AM', 'Morning shift from 9:30', '09:30:00', '17:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `pms_task`
--

CREATE TABLE IF NOT EXISTS `pms_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `project` varchar(255) NOT NULL,
  `job_type` varchar(255) NOT NULL,
  `team_leader` varchar(255) NOT NULL,
  `start_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `end_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `overtime` varchar(255) NOT NULL,
  `rework` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
